package Lms.application;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Rules extends JFrame implements ActionListener{

    String name;
    JButton start, back;
    
    Rules(String name) {
        this.name = name;
        getContentPane().setBackground(Color.GRAY);
        setLayout(null);
        
        JLabel heading = new JLabel("Welcome " + name + " to LPU Library");
        heading.setBounds(50, 20, 700, 30);
        heading.setFont(new Font("Viner Hand ITC", Font.BOLD, 28));
        heading.setForeground(Color.BLACK);
        add(heading);
        
        JLabel rules = new JLabel();
        rules.setBounds(20, 90, 700, 350);
        rules.setFont(new Font("Tahoma", Font.PLAIN, 16));
        rules.setText(
           "<html>"+ 
                "1. Valid LPU ID Card: Only students, faculty, and staff with a valid LPU ID card are allowed to access the library facilities and borrow books.\n" +
                    "" + "<br><br>" +
                "2. Silence Zone: The library is a designated \"Silence Zone,\" and users are expected to maintain silence to create a conducive environment for study and research.\n" +
"                   " + "<br><br>" +
                "3. Bags and Belongings: Users must deposit their bags, briefcases, and other belongings at the baggage counter before entering the library. Only personal study materials, such as laptops and notebooks, are allowed inside." + "<br><br>" +
                "4. Mobile Phones: Mobile phones must be kept on silent mode or switched off within the library premises. Loud ringtones and phone conversations are strictly prohibited." + "<br><br>" +
                "5. Eating and Drinking: Eating, drinking, or chewing gum is not allowed inside the library to maintain cleanliness and preserve the books.\n" + "<br><br>" +
                       " PRESS AGREE FOR CONTINUE"+
           "<html>"

        );
        add(rules);
        
        back = new JButton("Back");
        back.setBounds(250, 500, 100, 30);
        back.setBackground(Color.WHITE);
        back.setForeground(Color.BLACK);
        back.addActionListener(this);
        add(back);
        
        start = new JButton("Agree");
        start.setBounds(400, 500, 100, 30);
        start.setBackground(Color.WHITE);
        start.setForeground(Color.BLACK);
        start.addActionListener(this);
        add(start);
        
        setSize(800, 650);
        setLocation(350, 100);
        setVisible(true);
    }
    
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == start) {
            setVisible(false);
            new Lib(name);
        } else {
            setVisible(false);
            new Login();
        }
    }
    
    public static void main(String[] args) {
        new Rules("User");
    }
}
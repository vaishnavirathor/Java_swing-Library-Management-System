package Lms.application;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Lib extends JFrame implements ActionListener {
    
    String questions[][] = new String[10][5];
    String answers[][] = new String[10][2];
    String useranswers[][] = new String[10][1];
    JLabel qno, question;
    JRadioButton opt1, opt2, opt3, opt4;
    ButtonGroup groupoptions;
    JButton next, submit, lifeline;
    
    public static int timer = 69;
    public static int ans_given = 0;
    public static int count = 0;
    public static int score = 0;
    
    String name;
    
    Lib(String name) {
        this.name = name;
        setBounds(50, 0, 1440, 850);
        getContentPane().setBackground(new Color(160,160,160));
        setLayout(null);
        
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/p_1.jpg"));
        JLabel image = new JLabel(i1);
        image.setBounds(0, 0, 1440, 392);
        add(image);
        
        qno = new JLabel();
        qno.setBounds(100, 450, 50, 30);
        qno.setFont(new Font("Tahoma", Font.PLAIN, 24));
        add(qno);
        
        question = new JLabel();
        question.setBounds(150, 450, 900, 30);
        question.setFont(new Font("Tahoma", Font.PLAIN, 24));
        add(question);
        
        questions[0][0] = "Robin Sharma";
        questions[0][1] = "The 5 AM CLUB";
        questions[0][2] = "The Leader who had No Title";
        questions[0][3] = "The Monk who Sold his Ferrari";
        questions[0][4] = "The Secret Letters";

        questions[1][0] = "Joseph Murphy";
        questions[1][1] = "How to use Power Of Prayer";
        questions[1][2] = "Magic Faith";
        questions[1][3] = "How to Attract Money";
        questions[1][4] = "The Power of Subconsious Mind";

        questions[2][0] = "J.K Rowling";
        questions[2][1] = "Harry Potter";
        questions[2][2] = "The Ickabog";
        questions[2][3] = "The Cuckoo's Calling";
        questions[2][4] = "Caasual Vacancy";

        questions[3][0] = "Danielle Steel";
        questions[3][1] = "Pallazo";
        questions[3][2] = "The Wedding Planner";
        questions[3][3] = "Zoya";
        questions[3][4] = "Invisible";

        questions[4][0] = "Charles Dickens";
        questions[4][1] = " A Tale of Two Cities";
        questions[4][2] = "Great Expectations";
        questions[4][3] = "The Pickwick Papers";
        questions[4][4] = "Hard Times";

        questions[5][0] = "Dan Brown";
        questions[5][1] = "The Da Vinci Code";
        questions[5][2] = "Origin";
        questions[5][3] = "Inferno";
        questions[5][4] = "Angels and Demons";

        questions[6][0] = "Arundhati Roy";
        questions[6][1] = "Azadi";
        questions[6][2] = "The Algebra of Infinite Justice";
        questions[6][3] = "The cost of living";
        questions[6][4] = "Capitalism: A Ghost Story";

        questions[7][0] = "Rabindranath Tagore";
        questions[7][1] = "Gitanjali";
        questions[7][2] = "Kabuliwala";
        questions[7][3] = "The Post Office";
        questions[7][4] = "Stray Birds";

        questions[8][0] = "Stephen King";
        questions[8][1] = "IT";
        questions[8][2] = "The Shining";
        questions[8][3] = "Carrie";
        questions[8][4] = "Misery";

        questions[9][0] = "Amitav Ghosh";
        questions[9][1] = "Sea of Poppies";
        questions[9][2] = "River of Smoke";
        questions[9][3] = "The Hungry Tide";
        questions[9][4] = "Flood Of Fire";
        
        answers[0][1] = "The Leader who had No Title";
        answers[1][1] = "Magic Faith";
        answers[2][1] = "Harry Potter";
        answers[3][1] = "Zoya";
        answers[4][1] = "Hard Times";
        answers[5][1] = "Origin";
        answers[6][1] = "Azadi";
        answers[7][1] = "The Post Office";
        answers[8][1] = "Misery";
        answers[9][1] = "Flood Of Fire";
        
        opt1 = new JRadioButton();
        opt1.setBounds(170, 520, 700, 30);
        opt1.setBackground(new Color(192,192,192));
        opt1.setFont(new Font("Dialog", Font.PLAIN, 20));
        add(opt1);
        
        opt2 = new JRadioButton();
        opt2.setBounds(170, 560, 700, 30);
        opt2.setBackground(new Color(192,192,192));
        opt2.setFont(new Font("Dialog", Font.PLAIN, 20));
        add(opt2);
        
        opt3 = new JRadioButton();
        opt3.setBounds(170, 600, 700, 30);
        opt3.setBackground(new Color(192,192,192));
        opt3.setFont(new Font("Dialog", Font.PLAIN, 20));
        add(opt3);
        
        opt4 = new JRadioButton();
        opt4.setBounds(170, 640, 700, 30);
        opt4.setBackground(new Color(192,192,192));
        opt4.setFont(new Font("Dialog", Font.PLAIN, 20));
        add(opt4);
        
        groupoptions = new ButtonGroup();
        groupoptions.add(opt1);
        groupoptions.add(opt2);
        groupoptions.add(opt3);
        groupoptions.add(opt4);
        
        next = new JButton("Next");
        next.setBounds(1100, 550, 200, 40);
        next.setFont(new Font("Tahoma", Font.PLAIN, 22));
        next.setBackground(Color.WHITE);
        next.setForeground(Color.BLACK);
        next.addActionListener(this);
        add(next);
        
        lifeline = new JButton("Already Issued");
        lifeline.setBounds(1100, 630, 200, 40);
        lifeline.setFont(new Font("Tahoma", Font.PLAIN, 22));
        lifeline.setBackground(Color.WHITE);
        lifeline.setForeground(Color.BLACK);
        lifeline.addActionListener(this);
        add(lifeline);
        
        submit = new JButton("Submit");
        submit.setBounds(1100, 710, 200, 40);
        submit.setFont(new Font("Tahoma", Font.PLAIN, 22));
        submit.setBackground(Color.WHITE);
        submit.setForeground(Color.BLACK);
        submit.addActionListener(this);
        submit.setEnabled(false);
        add(submit);
        
        start(count);
        
        setVisible(true);
    }
    
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == next) {
            repaint();
            opt1.setEnabled(true);
            opt2.setEnabled(true);
            opt3.setEnabled(true);
            opt4.setEnabled(true);
            
            ans_given = 1;
            if (groupoptions.getSelection() == null) {
               useranswers[count][0] = "";
            } else {
                useranswers[count][0] = groupoptions.getSelection().getActionCommand();
            }
            
            if (count == 8) {
                next.setEnabled(false);
                submit.setEnabled(true);
            }
            
            count++;
            start(count);
        } else if (ae.getSource() == lifeline) {
            if (count == 2 || count == 4 || count == 6 || count == 8 || count == 9) {
                opt2.setEnabled(false);
                opt3.setEnabled(false);
            } else {
                opt1.setEnabled(false);
                opt4.setEnabled(false);
            }
//            lifeline.setEnabled(false);
        } else if (ae.getSource() == submit) {
            ans_given = 1;
            if (groupoptions.getSelection() == null) {
                useranswers[count][0] = "";
            } else {
                useranswers[count][0] = groupoptions.getSelection().getActionCommand();
            }

            for (int i = 0; i < useranswers.length; i++) {
                if (useranswers[i][0].equals(answers[i][1]) ) {
                    score += 1;
                } else {
                    score += 0;
                }
            }
            setVisible(false);
            new Score(name, score);
        }
    }
    
    public void paint(Graphics g) {
        super.paint(g);
        
        String time = "Time left - " + timer + " seconds"; // 15
        g.setColor(new Color(160,160,160));
        g.setFont(new Font("Tahoma", Font.BOLD, 25));
        
        if (timer > 0) { 
            g.drawString(time, 1100, 500);
        } else {
            g.drawString("Times up!!", 1100, 500);
        }
        
        timer--; 
        
        try {
            Thread.sleep(1000);
            repaint();
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        if (ans_given == 1) {
            ans_given = 0;
            timer = 88;
        } else if (timer < 0) {
            timer = 69;
            opt1.setEnabled(true);
            opt2.setEnabled(true);
            opt3.setEnabled(true);
            opt4.setEnabled(true);
            
            if (count == 8) {
                next.setEnabled(false);
                submit.setEnabled(true);
            }
            if (count == 9) { // submit button
                if (groupoptions.getSelection() == null) {
                   useranswers[count][0] = "";
                } else {
                    useranswers[count][0] = groupoptions.getSelection().getActionCommand();
                }
                
                for (int i = 0; i < useranswers.length; i++) {
                    if (useranswers[i][0].equals(answers[i][1])) {
                        score += 1;
                    }
                }
                setVisible(false);
                new Score(name, score);
            } else { // next button
                if (groupoptions.getSelection() == null) {
                   useranswers[count][0] = "";
                } else {
                    useranswers[count][0] = groupoptions.getSelection().getActionCommand();
                }
                count++; // 0 // 1
                start(count);
            }
        }
        
    }
    
    public void start(int count) {
        qno.setText("" + (count + 1) + ". ");
        question.setText(questions[count][0]);
        opt1.setText(questions[count][1]);
        opt1.setActionCommand(questions[count][1]);
        
        opt2.setText(questions[count][2]);
        opt2.setActionCommand(questions[count][2]);
        
        opt3.setText(questions[count][3]);
        opt3.setActionCommand(questions[count][3]);
        
        opt4.setText(questions[count][4]);
        opt4.setActionCommand(questions[count][4]);
        
        groupoptions.clearSelection();
    }
    
    public static void main(String[] args) {
        new Lib("User");
    }
}